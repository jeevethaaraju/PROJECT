import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import javax.swing.text.AbstractDocument;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONArray;
import org.json.JSONObject;

public class INPUTMARK extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTable table;
    private DefaultTableModel tableModel;
    private String lecture_id;
    private String name;
    /**
     * Create the application.
     */
    public INPUTMARK(String lecture_id,String name) {
        this.lecture_id = lecture_id;
        this.name = name;
        initialize();
        loadData();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        setTitle("View Registered Students");
        setBounds(100, 100, 800, 400); // Increased width to accommodate Save buttons
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a table model with column names (including Save button)
        String[] columnNames = {"Number", "Matric", "Name", "Marks", "Save"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Allow editing only for the "Marks" column (index 3) and "Save" column (index 4)
                return column == 3 || column == 4;
            }
        };

        // Create a table with the table model
        table = new JTable(tableModel);

        // Set custom renderer and editor for the "Save" column (index 4)
        table.getColumnModel().getColumn(4).setCellRenderer(new ButtonRenderer());
        table.getColumnModel().getColumn(4).setCellEditor(new ButtonEditor(new JTextField()));

        // Set custom editor for the "Marks" column (index 3)
        JTextField marksField = new JTextField();
        ((AbstractDocument) marksField.getDocument()).setDocumentFilter(new MarksFilter());
        table.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(marksField));

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane);
    
        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Dispose the current window and go to LECTUREHOME
                dispose();
                LECTUREHOME lectureHome = new LECTUREHOME(lecture_id, name);
                lectureHome.setVisible(true);
            }
        });
    getContentPane().add(backButton, BorderLayout.SOUTH);
    }
    /**
     * Load data into the table from the server.
     */
    private void loadData() {
        try {
            // Construct the URL with lecture_id parameter
            String urlString = "http://localhost/project/getstudents.php";
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            // Construct the POST data
            String postData = "lecture_id=" + lecture_id;

            // Write POST data to the connection
            try (OutputStream os = conn.getOutputStream()) {
                byte[] postDataBytes = postData.getBytes("UTF-8");
                os.write(postDataBytes);
                os.flush();
            }

            // Read the response from the server
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // Parse JSON response
            JSONObject jsonResponse = new JSONObject(response.toString());

            // Check if the response contains an error
            if (jsonResponse.getString("status").equals("fail")) {
                JOptionPane.showMessageDialog(this, jsonResponse.getString("message"), "Error", JOptionPane.ERROR_MESSAGE);
                return; // Exit the method
            }

            // Get the array of students
            JSONArray jsonArray = jsonResponse.getJSONArray("students");

            // Add rows to the table model
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String number = String.valueOf(i + 1);
                String matric = jsonObject.getString("matric");
                String name = jsonObject.getString("student_name");
                String marks = jsonObject.getString("marks");

                // Add a row with editable marks field and save button
                tableModel.addRow(new Object[]{number, matric, name, marks, "Save"});
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to load data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Custom renderer for "Save" button
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);

        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }

    // Custom editor for "Save" button
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;
        private boolean isClicked;

        public ButtonEditor(JTextField textField) {
            super(textField);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                }
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            isClicked = true;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            if (isClicked) {
                // Perform save action (update marks)
                String marks = tableModel.getValueAt(table.getSelectedRow(), 3).toString(); // Assuming marks are in column index 3
                String matric = tableModel.getValueAt(table.getSelectedRow(), 1).toString(); // Assuming matric is in column index 1
                saveMarks(matric, marks);
            }
            isClicked = false;
            return label;
        }

        @Override
        public boolean stopCellEditing() {
            isClicked = false;
            return super.stopCellEditing();
        }

        @Override
        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }
    }

    // Method to save marks to the server
    private void saveMarks(String matric, String marks) {
        try {
            // Construct URL and open connection
            URL url = new URL("http://localhost/project/save_marks.php");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);

            // Construct POST data
            String postData = "lecture_id=" + lecture_id + "&matric=" + matric + "&marks=" + marks;

            // Write POST data to connection
            try (OutputStream os = conn.getOutputStream()) {
                byte[] postDataBytes = postData.getBytes("UTF-8");
                os.write(postDataBytes);
                os.flush();
            }

            // Read response from server
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // Display response (for debugging)
            System.out.println("Server response: " + response.toString());

            // Optional: Handle response (show message to user, update UI, etc.)
            JSONObject jsonResponse = new JSONObject(response.toString());
            String status = jsonResponse.getString("status");
            String message = jsonResponse.getString("message");
            if (status.equals("success")) {
                // Optionally update UI or show message
                JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Handle failure
                JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to save marks: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

 // Custom DocumentFilter to restrict input to numbers between 0 and 100
    class MarksFilter extends DocumentFilter {
        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (isValidInput(fb.getDocument().getText(0, fb.getDocument().getLength()) + string)) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (isValidInput(fb.getDocument().getText(0, fb.getDocument().getLength()).substring(0, offset) + text + fb.getDocument().getText(0, fb.getDocument().getLength()).substring(offset + length))) {
                super.replace(fb, offset, length, text, attrs);
            }
        }

        @Override
        public void remove(FilterBypass fb, int offset, int length) throws BadLocationException {
            if (isValidInput(fb.getDocument().getText(0, fb.getDocument().getLength()).substring(0, offset) + fb.getDocument().getText(0, fb.getDocument().getLength()).substring(offset + length))) {
                super.remove(fb, offset, length);
            }
        }

        private boolean isValidInput(String text) {
            try {
                if (text.isEmpty()) {
                    return true;
                }
                int value = Integer.parseInt(text);
                return value >= 0 && value <= 100;
            } catch (NumberFormatException e) {
                return false;
            }
        }
    }
    public static void main(String[] args) {
        // For testing purposes
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    INPUTMARK window = new INPUTMARK("lecturer123","hi");
                    window.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
