import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.json.JSONObject;

import java.awt.EventQueue;

public class STUDENTHOME extends JFrame {

    private static final long serialVersionUID = 1L;
    private String matric;
    private String studentName;
    private JTextField textField;
    private JPasswordField passwordField;
    private JButton btnChangePassword; // Added button for changing password

    /**
     * Create the application.
     */
    public STUDENTHOME(String matric, String studentName) {
        this.matric = matric;
        this.studentName = studentName;
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        setTitle("Student Home");
        setBounds(100, 100, 450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Welcome to Student Home, " + studentName);
        lblNewLabel.setBounds(50, 50, 350, 30);
        getContentPane().add(lblNewLabel);

        // Add buttons for options
        JButton registerSubjectButton = new JButton("Register Subject");
        registerSubjectButton.setBounds(50, 100, 130, 30);
        getContentPane().add(registerSubjectButton);

        JButton viewGradesButton = new JButton("View Grades");
        viewGradesButton.setBounds(180, 100, 130, 30);
        getContentPane().add(viewGradesButton);

        JButton changePasswordButton = new JButton("Change Password");
        changePasswordButton.setBounds(50, 150, 160, 30);
        getContentPane().add(changePasswordButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(320, 100, 90, 30);
        getContentPane().add(logoutButton);

        // Add action listeners for the buttons
        registerSubjectButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the REGISTER frame
                REGISTER registerFrame = new REGISTER(matric, studentName);
                registerFrame.setVisible(true);
                dispose(); // Close the current frame
            }
        });

        viewGradesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                VIEWGRADE viewGradeFrame = new VIEWGRADE(matric, studentName);
                viewGradeFrame.setVisible(true);
                dispose(); // Close the current frame
            }
        });

        changePasswordButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleChangePassword();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout",
                        JOptionPane.YES_NO_OPTION);
                if (response == JOptionPane.YES_OPTION) {
                    dispose();
                    // Optionally, navigate back to the login screen
                    EventQueue.invokeLater(new Runnable() {
                        public void run() {
                            try {
                                STUDENTLOGIN.main(null);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    });
                }
            }
        });
    }

    /**
     * Method to handle password change.
     */
    private void handleChangePassword() {
        JTextField currentPassword = new JPasswordField();
        JTextField newPassword = new JPasswordField();
        JTextField confirmPassword = new JPasswordField();

        Object[] message = {
            "Current Password:", currentPassword,
            "New Password:", newPassword,
            "Confirm New Password:", confirmPassword
        };

        int option = JOptionPane.showConfirmDialog(null, message, "Change Password", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String currentPwd = currentPassword.getText();
            String newPwd = newPassword.getText();
            String confirmPwd = confirmPassword.getText();

            if (!newPwd.equals(confirmPwd)) {
                JOptionPane.showMessageDialog(this, "New passwords do not match.");
                return;
            }

            if (changePassword(matric, currentPwd, newPwd)) {
                JOptionPane.showMessageDialog(this, "Password changed successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Password change failed. Please try again.");
            }
        }
    }

    /**
     * Method to change student password.
     */
    private boolean changePassword(String matricNumber, String currentPassword, String newPassword) {
        try {
            URL url = new URL("http://localhost/Project/update_password.php");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            con.setDoOutput(true);

            String urlParameters = "matric=" + matricNumber +
                                   "&currentPassword=" + currentPassword +
                                   "&newPassword=" + newPassword;

            // Write parameters to the request
            try (OutputStream os = con.getOutputStream()) {
                byte[] input = urlParameters.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            // Check response from server
            int responseCode = con.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }

                    JSONObject jsonResponse = new JSONObject(response.toString());
                    return jsonResponse.getString("status").equals("success");
                }
            } else {
                // Handle HTTP error response
                System.out.println("HTTP error: " + responseCode);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


    @Override
    public void setVisible(boolean visible) {
        super.setVisible(visible);
    }

    public static void main(String[] args) {
        // For testing purposes
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    STUDENTHOME window = new STUDENTHOME("matric123", "John Doe");
                    window.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
