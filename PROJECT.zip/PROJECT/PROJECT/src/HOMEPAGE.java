import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class HOMEPAGE {

    private JFrame frame;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    HOMEPAGE window = new HOMEPAGE();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public HOMEPAGE() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create a panel with GridBagLayout
        JPanel panel = new JPanel(new GridBagLayout());
        frame.getContentPane().add(panel);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Add padding

        JLabel welcomeLabel = new JLabel("WELCOME SAPS");
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(welcomeLabel, gbc);

        JButton lectureButton = new JButton("LECTURE");
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(lectureButton, gbc);

        JButton studentButton = new JButton("STUDENT");
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(studentButton, gbc);

        JButton adminButton = new JButton("ADMIN");
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(adminButton, gbc);

        lectureButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                LECTURELOGIN lectureLogin = new LECTURELOGIN();
                lectureLogin.setVisible(true);
                frame.dispose(); // Close the homepage window
            }
        });

        studentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                STUDENTLOGIN studentLogin = new STUDENTLOGIN();
                studentLogin.setVisible(true);
                frame.dispose(); // Close the homepage window
            }
        });

        adminButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ADMINLOGIN adminLogin = new ADMINLOGIN();
                adminLogin.setVisible(true);
                frame.dispose(); // Close the homepage window
            }
        });
    }

    public void setVisible(boolean visible) {
        frame.setVisible(visible);
    }
}
