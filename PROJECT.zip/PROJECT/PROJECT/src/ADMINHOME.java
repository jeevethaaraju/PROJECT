import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.net.URL;
import java.net.HttpURLConnection;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.net.URLEncoder;
import java.io.InputStreamReader;
import org.json.JSONObject;


public class ADMINHOME extends JFrame {

    private static final long serialVersionUID = 1L;
    private String admin_id;
    private String admin_name;

    /**
     * Create the application.
     */
    public ADMINHOME(String admin_id, String name) {
        this.admin_id = admin_id;
        this.admin_name = name;
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        setTitle("Admin Home");
        setBounds(100, 100, 450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Welcome to Admin Home, " + admin_name);
        lblNewLabel.setBounds(50, 50, 350, 30);
        getContentPane().add(lblNewLabel);

        // Add buttons for options
        JButton addStudentButton = new JButton("Add Students");
        addStudentButton.setBounds(50, 100, 200, 30);
        getContentPane().add(addStudentButton);

        JButton deleteStudentButton = new JButton("Delete Student");
        deleteStudentButton.setBounds(260, 100, 150, 30);
        getContentPane().add(deleteStudentButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(336, 11, 90, 30);
        getContentPane().add(logoutButton);

        // Add action listeners for the buttons
        addStudentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the ADDSTUDENT frame
                ADDSTUDENT addStudentFrame = new ADDSTUDENT(admin_id,admin_name);
                addStudentFrame.setVisible(true);
                dispose(); // Close the current frame
            }
        });

        deleteStudentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Prompt admin to enter matric to delete
                String studentToDelete = JOptionPane.showInputDialog(null, "Enter student's matric number to delete:");
                if (studentToDelete != null && !studentToDelete.isEmpty()) {
                    // Send POST request to deleteStudent.php
                    try {
                        URL url = new URL("http://localhost/project/deleteStudent.php");
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("POST");
                        conn.setDoOutput(true);
                        
                        // Send matric as POST parameter
                        String postData = "matric=" + URLEncoder.encode(studentToDelete, "UTF-8");
                        try (OutputStream os = conn.getOutputStream()) {
                            byte[] input = postData.getBytes("UTF-8");
                            os.write(input, 0, input.length);
                        }

                        // Read response from server
                        try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                            StringBuilder response = new StringBuilder();
                            String responseLine = null;
                            while ((responseLine = br.readLine()) != null) {
                                response.append(responseLine.trim());
                            }
                            System.out.println(response.toString()); // Print server response (for debugging)
                            
                            // Handle response from server (display success/failure message)
                            JSONObject jsonResponse = new JSONObject(response.toString());
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");
                            if (status.equals("success")) {
                                JOptionPane.showMessageDialog(null, message);
                            } else {
                                JOptionPane.showMessageDialog(null, message);
                            }
                        }
                        
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Failed to delete student.");
                    }
                }
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout",
                        JOptionPane.YES_NO_OPTION);
                if (response == JOptionPane.YES_OPTION) {
                    dispose();
                    // Optionally, navigate back to the login screen
                    EventQueue.invokeLater(new Runnable() {
                        public void run() {
                            try {
                                ADMINLOGIN.main(null);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    });
                }
            }
        });
    }

    /**
     * Method to simulate deletion of student (replace with actual database operation).
     * @param studentId The ID of the student to delete.
     * @return true if deletion is successful, false otherwise.
     */
    @Override
    public void setVisible(boolean visible) {
        super.setVisible(visible);
    }

    // Main method for testing
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                ADMINHOME adminHome = new ADMINHOME("admin_id", "admin_name");
                adminHome.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
