import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import org.json.JSONArray;
import org.json.JSONObject;

public class REGISTER {

    private JFrame frame;
    private JComboBox<String> subjectDropdown;
    private String studentMatric; // Assuming this will hold the student's matriculation number
    private String studentName;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    REGISTER window = new REGISTER();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public REGISTER(String studentMatric, String studentName) {
        this.studentMatric = studentMatric;
        this.studentName = studentName;
        initialize();
        fetchSubjects();
    }

    public REGISTER() {
        // TODO Auto-generated constructor stub
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblTitle = new JLabel("Register Subject");
        lblTitle.setBounds(150, 30, 150, 20);
        frame.getContentPane().add(lblTitle);

        JLabel lblSubjectName = new JLabel("Subject Name:");
        lblSubjectName.setBounds(50, 80, 100, 20);
        frame.getContentPane().add(lblSubjectName);

        subjectDropdown = new JComboBox<>();
        subjectDropdown.setBounds(150, 80, 200, 20);
        frame.getContentPane().add(subjectDropdown);

        JButton btnRegister = new JButton("Register");
        btnRegister.setBounds(50, 180, 100, 30);
        frame.getContentPane().add(btnRegister);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(250, 180, 100, 30);
        frame.getContentPane().add(btnBack);

        // Add action listeners for the buttons
        btnRegister.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String subjectName = (String) subjectDropdown.getSelectedItem();

                if (subjectName == null || subjectName.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please select a subject.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Implement the logic for registering the subject here
                    registerSubject(subjectName);
                }
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Navigate back to the student home page
                STUDENTHOME studentHome = new STUDENTHOME(studentMatric, studentName);
                studentHome.setVisible(true);
                frame.dispose();
            }
        });
    }

    public void setVisible(boolean visible) {
        frame.setVisible(visible);
    }

    private void fetchSubjects() {
        try {
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("http://localhost/project/getsubject.php"))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                JSONArray jsonArray = new JSONArray(response.body());
                ArrayList<String> subjects = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    subjects.add(jsonArray.getString(i));
                }

                // Populate the dropdown
                for (String subject : subjects) {
                    subjectDropdown.addItem(subject);
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to fetch subjects from server.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void registerSubject(String subjectName) {
        try {
            HttpClient client = HttpClient.newHttpClient();
            URI uri = URI.create("http://localhost/Project/register.php");

            // Prepare data to send to the server
            String data = "subjectName=" + subjectName + "&matric=" + studentMatric + "&studentName=" + studentName;

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(uri)
                    .header("Content-Type", "application/x-www-form-urlencoded")
                    .POST(HttpRequest.BodyPublishers.ofString(data))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Handle different response statuses
            if (response.statusCode() == 200) {
                JSONObject jsonResponse = new JSONObject(response.body());

                String status = jsonResponse.getString("status");
                switch (status) {
                    case "success":
                        JOptionPane.showMessageDialog(frame, "Subject registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case "already_registered":
                        JOptionPane.showMessageDialog(frame, "Subject already registered.", "Info", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case "error":
                        JOptionPane.showMessageDialog(frame, "Failed to register subject. Server error.", "Error", JOptionPane.ERROR_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(frame, "Unknown response from server.", "Error", JOptionPane.ERROR_MESSAGE);
                        break;
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to register subject. Server returned status: " + response.statusCode(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "An error occurred during registration: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}