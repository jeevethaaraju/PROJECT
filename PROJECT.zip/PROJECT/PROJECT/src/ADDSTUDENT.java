import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class ADDSTUDENT {

    private JFrame frame;
    private JTextField textFieldName;
    private JTextField textFieldMatric;
    private String admin_id;
    private String admin_name;
    private static final String DEFAULT_PASSWORD = "student"; // Default password for all students

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ADDSTUDENT window = new ADDSTUDENT("admin_id","admin_name");
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public ADDSTUDENT(String admin_id,String admin_name) {
        this.admin_id = admin_id;
        this.admin_name = admin_name;
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("WELCOME");
        lblNewLabel.setBounds(169, 11, 80, 14);
        frame.getContentPane().add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("Student Name");
        lblNewLabel_1.setBounds(26, 73, 92, 14);
        frame.getContentPane().add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("Matric Number");
        lblNewLabel_2.setBounds(26, 120, 80, 14);
        frame.getContentPane().add(lblNewLabel_2);

        textFieldName = new JTextField();
        textFieldName.setBounds(144, 70, 200, 20);
        frame.getContentPane().add(textFieldName);
        textFieldName.setColumns(10);

        textFieldMatric = new JTextField();
        textFieldMatric.setBounds(144, 117, 200, 20);
        frame.getContentPane().add(textFieldMatric);
        textFieldMatric.setColumns(10);

        JButton addstudentButton = new JButton("ADD STUDENT");
        addstudentButton.setBounds(287, 213, 113, 23);
        frame.getContentPane().add(addstudentButton);

        JButton backButton = new JButton("Back");
        backButton.setBounds(10, 213, 113, 23);
        frame.getContentPane().add(backButton);

        addstudentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String studentName = textFieldName.getText();
                String matricNumber = textFieldMatric.getText();

                if (!studentName.isEmpty() && !matricNumber.isEmpty()) {
                    boolean success = saveStudentData(studentName, matricNumber, DEFAULT_PASSWORD);
                    if (success) {
                        JOptionPane.showMessageDialog(frame, "Student added successfully");
                        textFieldName.setText("");
                        textFieldMatric.setText("");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Failed to add student", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        try {
                            ADMINHOME adminHome = new ADMINHOME(admin_id,admin_name); // Pass necessary parameters
                            adminHome.setVisible(true);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                });
            }
        });
    }

    private boolean saveStudentData(String studentName, String matricNumber, String password) {
        try {
            URL url = new URL("http://localhost/project/add_student.php");
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            con.setDoOutput(true);

            String urlParameters = "name=" + URLEncoder.encode(studentName, "UTF-8") +
                                   "&matric=" + URLEncoder.encode(matricNumber, "UTF-8") +
                                   "&password=" + URLEncoder.encode(password, "UTF-8");

            try (OutputStream os = con.getOutputStream()) {
                byte[] input = urlParameters.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String responseLine;
                while ((responseLine = br.readLine()) != null) {
                    response.append(responseLine.trim());
                }

                // Check the response from the server
                if (response.toString().equals("success")) {
                    return true;
                } else {
                    return false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void setVisible(boolean visible) {
        frame.setVisible(visible);
    }
}
