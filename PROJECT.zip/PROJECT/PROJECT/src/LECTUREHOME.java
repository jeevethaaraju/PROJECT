import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.EventQueue;

public class LECTUREHOME extends JFrame {

    private static final long serialVersionUID = 1L;
    private String lecture_id;
    private String name;

    /**
     * Create the application.
     */
    public LECTUREHOME(String lecture_id, String name) {
        this.lecture_id = lecture_id;
        this.name = name;
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        setTitle("Lecture Home");
        setBounds(100, 100, 450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        JLabel lblNewLabel = new JLabel("Welcome to Lecture Home, " + name);
        lblNewLabel.setBounds(50, 50, 350, 30);
        getContentPane().add(lblNewLabel);

        // Add buttons for options
        JButton viewRegisteredButton = new JButton("View Registered Students");
        viewRegisteredButton.setBounds(50, 100, 200, 30);
        getContentPane().add(viewRegisteredButton);

        JButton inputMarksButton = new JButton("Input Marks");
        inputMarksButton.setBounds(50, 141, 200, 30);
        getContentPane().add(inputMarksButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(336, 50, 90, 30);
        getContentPane().add(logoutButton);

        // Add action listeners for the buttons
        viewRegisteredButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the VIEWREGISTER frame
                VIEWREGISTER viewRegisterFrame = new VIEWREGISTER(lecture_id, name);
                viewRegisterFrame.setVisible(true);
                dispose(); // Close the current frame
            }
        });

        inputMarksButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the VIEWREGISTER frame
                INPUTMARK inputmarkFrame = new INPUTMARK(lecture_id,name);
                inputmarkFrame.setVisible(true);
                dispose(); // Close the current frame
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout",
                        JOptionPane.YES_NO_OPTION);
                if (response == JOptionPane.YES_OPTION) {
                    dispose();
                    // Optionally, navigate back to the login screen
                    EventQueue.invokeLater(new Runnable() {
                        public void run() {
                            try {
                                LECTURELOGIN.main(null);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    });
                }
            }
        });
    }

    @Override
    public void setVisible(boolean visible) {
        super.setVisible(visible);
    }
}
