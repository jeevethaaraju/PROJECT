import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.OutputStream;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VIEWGRADE extends JFrame {

    private static final long serialVersionUID = 1L;
    private JTable table;
    private DefaultTableModel tableModel;
    private String matric;
    private String studentName;

    /**
     * Create the application.
     */
    public VIEWGRADE(String matric, String studentName) {
        this.matric = matric;
        this.studentName = studentName;
        initialize();
        loadData();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        setTitle("View Students' Grades");
        setBounds(100, 100, 600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Create a table model with column names
        String[] columnNames = {"Number", "Subject Name", "Grade"};
        tableModel = new DefaultTableModel(columnNames, 0);

        // Create a table with the table model
        table = new JTable(tableModel);

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Create and add the back button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Dispose the current window and go to STUDENTHOME
                dispose();
                STUDENTHOME studentHome = new STUDENTHOME(matric, studentName);
                studentHome.setVisible(true);
            }
        });
        getContentPane().add(backButton, BorderLayout.SOUTH);
    }

    /**
     * Load data into the table from the server.
     */
    private void loadData() {
        try {
            // Construct the URL with matric parameter
            String urlString = "http://localhost/project/viewgrade.php";
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST"); // Change request method to POST
            conn.setDoOutput(true); // Enable output for POST request

            // Construct the POST data
            String postData = "matric=" + matric;

            // Write POST data to the connection
            try (OutputStream os = conn.getOutputStream()) {
                byte[] postDataBytes = postData.getBytes("UTF-8");
                os.write(postDataBytes);
                os.flush();
            }

            // Read the response from the server
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // Debugging: Print the received response
            System.out.println("Received response: " + response.toString());

            // Parse JSON response
            JSONTokener tokener = new JSONTokener(response.toString());
            JSONObject jsonResponse = new JSONObject(tokener);

            // Check if the response contains an error
            if (jsonResponse.getString("status").equals("fail")) {
                JOptionPane.showMessageDialog(this, jsonResponse.getString("message"), "Error", JOptionPane.ERROR_MESSAGE);
                return; // Exit the method
            }

            // Get the array of students' grades
            JSONArray jsonArray = jsonResponse.getJSONArray("grades");

            // Add rows to the table model
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String number = String.valueOf(i + 1);
                String subjectName = jsonObject.getString("subjectname");
                String grade = jsonObject.getString("grade");
                tableModel.addRow(new Object[]{number, subjectName, grade});
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Failed to load data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // For testing purposes
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                try {
                    VIEWGRADE window = new VIEWGRADE("matric123", "John Doe");
                    window.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
