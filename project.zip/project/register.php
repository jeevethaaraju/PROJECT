<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projectdad";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $matric = $_POST['matric'];
  $subjectName = $_POST['subjectName'];
  $studentName = $_POST['studentName'];

  // Retrieve the subjectcodeno and lecture_id from the subject table
  $sql = "SELECT subjectcodeno, lecture_id FROM subject WHERE subjectname = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("s", $subjectName);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $subjectcodeno = $row['subjectcodeno'];
    $lecture_id = $row['lecture_id'];

    // Check if the student is already registered for this subject
    $checkQuery = "SELECT * FROM register WHERE matric = ? AND subjectcodeno = ?";
    $stmt = $conn->prepare($checkQuery);
    $stmt->bind_param("ss", $matric, $subjectcodeno);
    $stmt->execute();
    $checkResult = $stmt->get_result();

    if ($checkResult->num_rows > 0) {
      // Student is already registered for this subject
      echo json_encode(['status' => 'already_registered', 'message' => 'Subject already registered']);
    } else {
      // Register the student for the subject
      $registerQuery = "INSERT INTO register (subjectname, matric, subjectcodeno, student_name, lecture_id) VALUES (?, ?, ?, ?, ?)";
      $stmt = $conn->prepare($registerQuery);
      $stmt->bind_param("sssss", $subjectName, $matric, $subjectcodeno, $studentName, $lecture_id);

      if ($stmt->execute()) {
        // Registration successful
        echo json_encode(['status' => 'success', 'message' => 'Registration successful']);
      } else {
        // Registration failed, handle errors
        http_response_code(500);
        $error = $stmt->error;
        echo json_encode(['status' => 'error', 'message' => 'Error: ' . $error]);
      }
    }
  } else {
    // Subject not found
    echo json_encode(['status' => 'fail', 'message' => 'Subject not found']);
  }

  $stmt->close();
}

$conn->close();
?>