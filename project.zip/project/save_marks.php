<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projectdad";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if it's a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input parameters
    $lecture_id = isset($_POST['lecture_id']) ? $_POST['lecture_id'] : '';
    $matric = isset($_POST['matric']) ? $_POST['matric'] : '';
    $marks = isset($_POST['marks']) ? $_POST['marks'] : '';

    if (empty($lecture_id) || empty($matric) || empty($marks)) {
        echo json_encode(['status' => 'fail', 'message' => 'Missing parameters']);
        exit();
    }

    // Determine the grade based on the marks
    $grade = '';
    if ($marks >= 0 && $marks <= 39) {
        $grade = 'F';
    } elseif ($marks >= 40 && $marks <= 49) {
        $grade = 'E';
    } elseif ($marks >= 50 && $marks <= 59) {
        $grade = 'D';
    } elseif ($marks >= 60 && $marks <= 69) {
        $grade = 'C';
    } elseif ($marks >= 70 && $marks <= 79) {
        $grade = 'B';
    } elseif ($marks >= 80 && $marks <= 100) {
        $grade = 'A';
    } else {
        echo json_encode(['status' => 'fail', 'message' => 'Invalid marks value']);
        exit();
    }

    // Prepare and execute SQL statement to update marks and grade in register table
    $sql = "UPDATE register SET marks = ?, grade = ? WHERE lecture_id = ? AND matric = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo json_encode(['status' => 'fail', 'message' => 'Failed to prepare statement: ' . $conn->error]);
        exit();
    }
    $stmt->bind_param("ssss", $marks, $grade, $lecture_id, $matric);
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Marks and grade updated successfully']);
    } else {
        echo json_encode(['status' => 'fail', 'message' => 'Failed to update marks and grade: ' . $stmt->error]);
    }
    $stmt->close();
} else {
    echo json_encode(['status' => 'fail', 'message' => 'Invalid request method']);
}

$conn->close();
?>
