<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projectdad";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lecture_id = $_POST['lecture_id'];
    $password = $_POST['password'];

    $sql = "SELECT name FROM lecture WHERE lecture_id = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $lecture_id, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode(['status' => 'success', 'name' => $row['name']]);
    } else {
        echo json_encode(['status' => 'fail', 'message' => 'Invalid matric number or password']);
    }
    $stmt->close();
}

$conn->close();
?>