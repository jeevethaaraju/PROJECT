<?php
error_reporting(0); // Suppress all PHP errors and warnings

$servername = "localhost";
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "projectdad"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    $response = array(
        'status' => 'error',
        'message' => 'Database connection failed: ' . $conn->connect_error
    );
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Check if POST parameters are set
if (!isset($_POST['matric']) || !isset($_POST['currentPassword']) || !isset($_POST['newPassword'])) {
    $response = array(
        'status' => 'error',
        'message' => 'Missing parameters'
    );
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Retrieve POST parameters
$matricNumber = $_POST['matric'];
$currentPassword = $_POST['currentPassword'];
$newPassword = $_POST['newPassword'];

// Ensure the parameters are not empty
if (empty($matricNumber) || empty($currentPassword) || empty($newPassword)) {
    $response = array(
        'status' => 'error',
        'message' => 'Parameters cannot be empty'
    );
    header('Content-Type: application/json');
    echo json_encode($response);
    exit();
}

// Query to fetch current password from the database
$sql = "SELECT password FROM student WHERE matric = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $matricNumber);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 1) {
    $stmt->bind_result($hashedPassword);
    $stmt->fetch();

    // Verify current password
    if ($currentPassword == $hashedPassword) {  // Assuming passwords are stored as plain text, which is not secure
        // Update the password
        $updateSql = "UPDATE student SET password = ? WHERE matric = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param('ss', $newPassword, $matricNumber);

        if ($updateStmt->execute()) {
            $response = array(
                'status' => 'success',
                'message' => 'Password updated successfully'
            );
        } else {
            $response = array(
                'status' => 'error',
                'message' => 'Error updating password'
            );
        }
    } else {
        $response = array(
            'status' => 'error',
            'message' => 'Current password is incorrect'
        );
    }
} else {
    $response = array(
        'status' => 'error',
        'message' => 'Student not found'
    );
}

// Close statement and database connection
$stmt->close();
$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
