<?php
$servername = "localhost";
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "projectdad"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['name']) && isset($_POST['matric']) && isset($_POST['password'])) {
    $name = $_POST['name'];
    $matric = $_POST['matric'];
    $password = $_POST['password'];

    $sql = "INSERT INTO student (name, matric, password) VALUES ('$name', '$matric', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "success";
    } else {
        echo "error: " . $conn->error;
    }
} else {
    // Debugging: Print received POST data
    echo "Missing POST data: ";
    echo "name: " . (isset($_POST['name']) ? "received" : "missing") . ", ";
    echo "matric: " . (isset($_POST['matric']) ? "received" : "missing") . ", ";
    echo "password: " . (isset($_POST['password']) ? "received" : "missing");
}

$conn->close();
?>