<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projectdad";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['status' => 'failure', 'message' => 'Connection failed: ' . $conn->connect_error]);
    exit();
}

// Get POST data
$matricNumber = $_POST['matric'] ?? '';
$currentPassword = $_POST['currentPassword'] ?? '';
$newPassword = $_POST['newPassword'] ?? '';

// Validate input
if (empty($matricNumber) || empty($currentPassword) || empty($newPassword)) {
    echo json_encode(['status' => 'failure', 'message' => 'All fields are required.']);
    exit();
}

// Check if matric number exists and current password is correct
$sql = "SELECT password FROM students WHERE matric = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['status' => 'failure', 'message' => 'Prepare statement failed: ' . $conn->error]);
    exit();
}
$stmt->bind_param("s", $matricNumber);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(['status' => 'failure', 'message' => 'Invalid matric number or password.']);
    exit();
}

$row = $result->fetch_assoc();
$storedPassword = $row['password'];

if (!password_verify($currentPassword, $storedPassword)) {
    echo json_encode(['status' => 'failure', 'message' => 'Invalid matric number or password.']);
    exit();
}

// Update password
$newPasswordHash = password_hash($newPassword, PASSWORD_BCRYPT);
$sql = "UPDATE students SET password = ? WHERE matric = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo json_encode(['status' => 'failure', 'message' => 'Prepare statement failed: ' . $conn->error]);
    exit();
}
$stmt->bind_param("ss", $newPasswordHash, $matricNumber);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Password changed successfully.']);
} else {
    echo json_encode(['status' => 'failure', 'message' => 'Password change failed: ' . $stmt->error]);
}

// Close connections
$stmt->close();
$conn->close();
?>