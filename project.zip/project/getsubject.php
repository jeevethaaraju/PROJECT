<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projectdad";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize an empty array to hold subject names
$subjects = array();

// Query to select subject names
$sql = "SELECT subjectname FROM subject";
$result = $conn->query($sql);

// Check if the query was successful
if ($result) {
    // Fetch subject names and store them in the $subjects array
    while ($row = $result->fetch_assoc()) {
        $subjects[] = $row['subjectname'];
    }
} else {
    // If the query failed, display an error message
    die("Error retrieving subject names: " . $conn->error);
}

// Close the database connection
$conn->close();

// Set response header to indicate JSON content
header('Content-Type: application/json');

// Encode the $subjects array to JSON and output it
echo json_encode($subjects);
?>