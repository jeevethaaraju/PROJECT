<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projectdad";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming lecture_id is sent via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lecture_id = $_POST['lecture_id'];

    $sql = "SELECT matric, student_name,Mark FROM register WHERE lecture_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $lecture_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $students = array();
    while ($row = $result->fetch_assoc()) {
        $students[] = array('matric' => $row['matric'], 'student_name' => $row['student_name'],'Mark' => $row['Mark']);
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode($students);
}
?>
