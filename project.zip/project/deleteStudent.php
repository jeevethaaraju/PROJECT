<?php
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "projectdad"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if matric parameter is set in POST request
if (isset($_POST['matric'])) {
    $matric = $_POST['matric'];

    // Prepare and bind
    $stmt = $conn->prepare("DELETE FROM student WHERE matric = ?");
    $stmt->bind_param("s", $matric);

    // Execute the statement
    if ($stmt->execute()) {
        $response = array("status" => "success", "message" => "Student deleted successfully.");
    } else {
        $response = array("status" => "error", "message" => "Failed to delete student.");
    }

    // Close statement
    $stmt->close();
} else {
    $response = array("status" => "error", "message" => "Matric number not provided.");
}

// Close connection
$conn->close();

// Return response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
