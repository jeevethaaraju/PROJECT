<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projectdad";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['lecture_id'])) {
        $lecture_id = $_POST['lecture_id'];

        $sql = "SELECT matric, student_name FROM register WHERE lecture_id = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo json_encode(['status' => 'fail', 'message' => 'Failed to prepare statement']);
            exit();
        }
        $stmt->bind_param("s", $lecture_id);
        $stmt->execute();
        $result = $stmt->get_result();

        $students = array();
        while ($row = $result->fetch_assoc()) {
            $students[] = $row;
        }

        if (!empty($students)) {
            echo json_encode(['status' => 'success', 'students' => $students]);
        } else {
            echo json_encode(['status' => 'fail', 'message' => 'No students found']);
        }

        $stmt->close();
    } else {
        echo json_encode(['status' => 'fail', 'message' => 'Missing parameters']);
    }
}

$conn->close();
?>