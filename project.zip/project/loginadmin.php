<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projectdad";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lecture_id = $_POST['admin_id'];
    $password = $_POST['password'];

    $sql = "SELECT admin_name FROM admin WHERE admin_id = ? AND admin_password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $lecture_id, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode(['status' => 'success', 'admin_name' => $row['admin_name']]);
    } else {
        echo json_encode(['status' => 'fail', 'message' => 'Invalid admin ID or password']);
    }
    $stmt->close();
}

$conn->close();
?>