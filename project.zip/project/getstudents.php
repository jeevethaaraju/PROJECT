<?php
// Check if lecture_id is provided
if (!isset($_POST['lecture_id'])) {
    $response = array(
        "status" => "fail",
        "message" => "Lecture ID not provided"
    );
    echo json_encode($response);
    exit;
}

$lecture_id = $_POST['lecture_id'];

// Database credentials
$servername = "localhost";
$username = "root";     // Replace with your database username
$password = "";         // Replace with your database password
$dbname = "projectdad";    // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    $response = array(
        "status" => "fail",
        "message" => "Connection failed: " . $conn->connect_error
    );
    echo json_encode($response);
    exit;
}

// Prepare SQL statement to fetch student data
$sql = "SELECT matric, student_name, marks FROM register WHERE lecture_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $lecture_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if there are results
if ($result->num_rows > 0) {
    $students = array();
    while ($row = $result->fetch_assoc()) {
        // Add each student data to the array
        $student_data = array(
            "matric" => $row['matric'],
            "student_name" => $row['student_name'],
            "marks" => $row['marks']
        );
        $students[] = $student_data;
    }
    
    // Return success response with student data
    $response = array(
        "status" => "success",
        "students" => $students
    );
} else {
    // No students found for the given lecture_id
    $response = array(
        "status" => "fail",
        "message" => "No students found for lecture ID: " . $lecture_id
    );
}

// Close statement and connection
$stmt->close();
$conn->close();

// Return JSON response
echo json_encode($response);
?>