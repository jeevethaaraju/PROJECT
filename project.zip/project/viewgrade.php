<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projectdad";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['matric'])) {
        $matric = $_POST['matric'];

        $sql = "SELECT subjectname, grade FROM register WHERE matric = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo json_encode(['status' => 'fail', 'message' => 'Failed to prepare statement']);
            exit();
        }
        $stmt->bind_param("s", $matric);
        $stmt->execute();
        $result = $stmt->get_result();

        $grades = array();
        while ($row = $result->fetch_assoc()) {
            $grades[] = $row;
        }

        if (!empty($grades)) {
            echo json_encode(['status' => 'success', 'grades' => $grades]);
        } else {
            echo json_encode(['status' => 'fail', 'message' => 'No grades found']);
        }

        $stmt->close();
    } else {
        echo json_encode(['status' => 'fail', 'message' => 'Missing parameters']);
    }
}

$conn->close();
?>
